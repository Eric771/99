from .node import Node
from .connector import Connector
import threading,time,orjson,json,codecs

class Lesting:

    class Core:
        def __init__(self, lesting):
            self.lesting = lesting
            self.connector = Connector()

    class Storage:
        def __init__(self):
            self.user = {}
            self.chat = {}
            self.command = {
                "separator": " ",
                "prefix"   : ","
            }
            
    class User:

        def __init__(self, lesting):
            self.lesting = lesting
          
        def __getitem__(self, mid):
            if mid not in self.lesting.storage.user:
                self.lesting.storage.user[mid] = {
                    "blacklist" : False,
                    "squad"     : False,
                    "osquad"     : False,
                    "permission": 0,
                    "war": False,
                    "ticket":None
                }
            return self.lesting.storage.user[mid]
            

        def __iter__(self):
            return iter(self.lesting.storage.user)

#######Status
    class Status:
    	def __init__(self):
    		self.status = {}
    class Setbot:
        def __init__(self, lesting):
            self.lesting = lesting
            
        def __getitem__(self,mid):
        	if mid not in self.lesting.bot.status:
        		self.lesting.bot.status["status"] = {}
        	return self.lesting.bot.status["status"]

        def __iter__(self):
            return iter(self.lesting.bot.status)

######

#######Data
    class Data:
    	def __init__(self):
    		with open("data.json", "rb") as r:
    			self.data = json.load(r)
    		self.protect = self.data["protect"]
    		self.master = self.data["master"]
    		self.ws = self.data["ws"]
    		self.skick = self.data["skick"]
    		self.cb = self.data["scb"]
    		self.byall = self.data["sbyall"]
    		self.respon = self.data["srp"]
    		self.invite = self.data["invite"]
    		
    		
    class Setting:
        def __init__(self, lesting):
            self.lesting = lesting
            
        def __getitem__(self,mid):
        	if mid not in self.lesting.data.protect+self.lesting.data.master+self.lesting.data.ws:
        		self.lesting.data = {
        			"protect": {mid:False},
        			"ws": {mid:False},
        			"master": {mid:False},
        			"skick":{"STKVER":"","STKPKGID":"","STKID":0},
        			"scb":{"STKVER":"","STKPKGID":"","STKID":0},
        			"sbyall":{"STKVER":"","STKPKGID":"","STKID":0},
        			"invite":{"STKVER":"","STKPKGID":"","STKID":0},
        			"srp":{"STKVER":"","STKPKGID":"","STKID":0,"respon":""},
        		}
        	
        	return self.lesting.data

        def __iter__(self):
            return iter(self.lesting.data)

######


    class Chat:
        def __init__(self, lesting):
            self.lesting = lesting

        def __getitem__(self, gid):
            if gid not in self.lesting.storage.chat:
                self.lesting.storage.chat[gid] = {
                    "squad": []
                }
            return self.lesting.storage.chat[gid]

    class Command:
        def __init__(self, lesting):
            self.lesting = lesting

        def __call__(self, string):
            splited = string.split(self.lesting.storage.command["separator"])
            prefix = splited[0].lower()
            if prefix[:len(self.lesting.storage.command["prefix"])] == self.lesting.storage.command["prefix"]:
                arg = [prefix[len(self.lesting.storage.command["prefix"]):]]
                if not arg[0]: arg = []
                args = arg + splited[1:]
                return args[0], args[1:]
            return False, []

    class Messenger:
        MAX_CACHE = 1000

        def __init__(self):
            self.cache = []
            self.lock = threading.Lock()

        def __call__(self, op, *key):
            key = "&".join(map(str, (op.createdTime if op.type not in [25, 26] else op.message.id,) + key))
            with self.lock:
                if key in self.cache:
                    return False
                self.cache.append(key)
                if len(self.cache) > self.MAX_CACHE:
                    self.cache = self.cache[self.MAX_CACHE//2]
                return True

    def __init__(self):
        self.storage = Lesting.Storage()
        self.bot = Lesting.Status()
        self.data = Lesting.Data()
        self.core = Lesting.Core(self)
        self.user = Lesting.User(self)
        self.chat = Lesting.Chat(self)
        self.command = Lesting.Command(self)
        self.messenger = Lesting.Messenger()
        self.status = Lesting.Setbot(self)
        self.protect = Lesting.Setting(self)
        self.ws = Lesting.Setting(self)
        self.master = Lesting.Setting(self)
        
        self.skick = Lesting.Setting(self)
        self.cb = Lesting.Setting(self)
        self.byall = Lesting.Setting(self)
        self.respon = Lesting.Setting(self)
        self.invite = Lesting.Setting(self)
    

    def Node(self, client,sockaddr,file):
        return Node(self, client,sockaddr,file)



    